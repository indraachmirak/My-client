My Client (Fabric, Minecraft 1.21.11, Java 21)

Setup
1. Install JDK 21 and IntelliJ IDEA.
2. Open this folder in IntelliJ. If there is no gradlew file, run:  gradle wrapper
   (or copy gradlew, gradlew.bat and the gradle/ folder from the official Fabric example mod).
3. Build:  ./gradlew build     -> jar in build/libs/
4. Test in dev:  ./gradlew runClient
5. Put the jar in your mods folder with Fabric Loader and Fabric API.

In game: Right Shift opens the menu (rebind it in Controls).
Add a feature: copy a class in modules/, edit it, add it in ModuleManager.init().
If versions fail to resolve, update gradle.properties from the Fabric develop page.
