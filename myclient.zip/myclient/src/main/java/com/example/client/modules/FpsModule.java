package com.example.client.modules;

import com.example.client.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class FpsModule extends Module {
    public FpsModule() { super("FPS", "Shows your frame rate.", true); }

    @Override
    public void renderHud(DrawContext context, MinecraftClient client) {
        context.drawText(client.textRenderer, client.getCurrentFps() + " FPS", 4, 4, 0xFFFFFFFF, true);
    }
}
