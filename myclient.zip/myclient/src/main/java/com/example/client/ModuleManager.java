package com.example.client;

import com.example.client.modules.CoordsModule;
import com.example.client.modules.FpsModule;
import com.example.client.modules.KeystrokesModule;
import com.example.client.modules.ToggleSprintModule;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("myclient.json");

    public static final List<Module> MODULES = new ArrayList<>();

    public static void init() {
        MODULES.add(new FpsModule());
        MODULES.add(new CoordsModule());
        MODULES.add(new KeystrokesModule());
        MODULES.add(new ToggleSprintModule());
        load();
    }

    public static void load() {
        if (!Files.exists(CONFIG)) return;
        try (Reader r = Files.newBufferedReader(CONFIG)) {
            Map<String, Boolean> saved = GSON.fromJson(r, new TypeToken<Map<String, Boolean>>() {}.getType());
            if (saved == null) return;
            for (Module m : MODULES) {
                Boolean v = saved.get(m.name);
                if (v != null) m.setEnabled(v);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        Map<String, Boolean> out = new HashMap<>();
        for (Module m : MODULES) out.put(m.name, m.isEnabled());
        try (Writer w = Files.newBufferedWriter(CONFIG)) {
            GSON.toJson(out, w);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
