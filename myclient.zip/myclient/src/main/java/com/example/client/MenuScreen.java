package com.example.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Simple module list. Each button toggles one module and saves the config. */
public class MenuScreen extends Screen {
    public MenuScreen() { super(Text.literal("My Client")); }

    @Override
    protected void init() {
        int w = 200, h = 20, gap = 4;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - (ModuleManager.MODULES.size() * (h + gap)) / 2;
        for (Module m : ModuleManager.MODULES) {
            addDrawableChild(ButtonWidget.builder(label(m), button -> {
                m.toggle();
                button.setMessage(label(m));
                ModuleManager.save();
            }).dimensions(x, y, w, h).build());
            y += h + gap;
        }
    }

    private static Text label(Module m) {
        return Text.literal(m.name + ": " + (m.isEnabled() ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFFFF);
    }

    @Override
    public boolean shouldPause() { return false; }
}
