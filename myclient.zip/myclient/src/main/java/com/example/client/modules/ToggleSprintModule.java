package com.example.client.modules;

import com.example.client.Module;
import net.minecraft.client.MinecraftClient;

/** Keeps you sprinting while you hold forward. Normal sprint rules (hunger, collisions) still apply. */
public class ToggleSprintModule extends Module {
    public ToggleSprintModule() { super("Toggle Sprint", "Sprints automatically while moving forward.", false); }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.options.forwardKey.isPressed()
                && !client.player.horizontalCollision
                && !client.player.isSneaking()) {
            client.player.setSprinting(true);
        }
    }
}
