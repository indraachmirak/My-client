package com.example.client.modules;

import com.example.client.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class CoordsModule extends Module {
    public CoordsModule() { super("Coordinates", "Shows your position.", true); }

    @Override
    public void renderHud(DrawContext context, MinecraftClient client) {
        String s = String.format("XYZ %.1f / %.1f / %.1f", client.player.getX(), client.player.getY(), client.player.getZ());
        context.drawText(client.textRenderer, s, 4, 16, 0xFFFFFFFF, true);
    }
}
