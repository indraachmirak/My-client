package com.example.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Base class for every feature. Subclass it, then register it in ModuleManager. */
public abstract class Module {
    public final String name;
    public final String description;
    private boolean enabled;

    protected Module(String name, String description, boolean enabledByDefault) {
        this.name = name;
        this.description = description;
        this.enabled = enabledByDefault;
    }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean value) { this.enabled = value; }
    public void toggle() { enabled = !enabled; }

    /** Runs every client tick while enabled and in a world. */
    public void onTick(MinecraftClient client) {}

    /** Runs every frame while enabled and in a world. */
    public void renderHud(DrawContext context, MinecraftClient client) {}
}
