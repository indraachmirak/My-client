package com.example.client.modules;

import com.example.client.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;

public class KeystrokesModule extends Module {
    public KeystrokesModule() { super("Keystrokes", "Shows WASD and jump.", true); }

    @Override
    public void renderHud(DrawContext context, MinecraftClient client) {
        int x = 4, y = 32, s = 22, g = 2;
        key(context, client, "W", client.options.forwardKey, x + s + g, y, s, s);
        key(context, client, "A", client.options.leftKey, x, y + s + g, s, s);
        key(context, client, "S", client.options.backKey, x + s + g, y + s + g, s, s);
        key(context, client, "D", client.options.rightKey, x + 2 * (s + g), y + s + g, s, s);
        key(context, client, "JUMP", client.options.jumpKey, x, y + 2 * (s + g), 3 * s + 2 * g, 14);
    }

    private void key(DrawContext c, MinecraftClient client, String label, KeyBinding kb, int x, int y, int w, int h) {
        int bg = kb.isPressed() ? 0xAAFFFFFF : 0x88000000;
        int fg = kb.isPressed() ? 0xFF000000 : 0xFFFFFFFF;
        c.fill(x, y, x + w, y + h, bg);
        int tw = client.textRenderer.getWidth(label);
        c.drawText(client.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, fg, false);
    }
}
